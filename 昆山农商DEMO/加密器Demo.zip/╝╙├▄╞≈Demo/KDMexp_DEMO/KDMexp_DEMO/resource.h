//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ATM_DEMO.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ATM_DEMO_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_COMBO_COMM                  1001
#define IDC_TERM_CODE                   1002
#define IDC_RAND                        1003
#define IDC_CHECK                       1004
#define IDC_COMB_KEY                    1005
#define IDC_EXCUTE                      1006
#define IDC_TMK_LEN                     1007
#define IDC_LOG                         1008
#define IDC_CLEAR_LOG                   1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
