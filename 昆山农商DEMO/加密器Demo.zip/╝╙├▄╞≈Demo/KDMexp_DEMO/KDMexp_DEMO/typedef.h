/*-------------------------------------------

	Name		:	typedef.h
	Description	:	
	Author		:	yanghb@keyou.cn
	Version		:	v1.0

---------------------------------------------*/


#ifndef MY_TYPEDEF_H
#define MY_TYPEDEF_H


typedef unsigned char	uchar;
typedef unsigned short	ushort;
typedef unsigned int	uint;
typedef unsigned long	ulong;


#endif